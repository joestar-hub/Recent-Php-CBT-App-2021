<?php
    ob_start();
    session_start();
    include_once "../includes/dbconnection.php";
	if(!(isset($_SESSION["s_firstname"]))){
        die("Access denied");
    }
	
	function test_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }


/**We call database default values */

$sql="SELECT * FROM administrator";

$g=mysqli_query($conn,$sql);

$start=mysqli_fetch_assoc($g);
  
$falseEmail=$start["email"];
$falsePassword=$start["password"];


    













/**We call database default values */














     
    $errTime=$errEmail=$errPassword="";





	if (isset($_POST["submit"])) {
		
		if(empty($_POST["expirytime"])){
			$errTime = "Pls Put Expiry Countdown time";
		}else{
			$expiry = test_input($_POST["expirytime"]);
			// check if name only contains letters and whitespace
			 
				$expiry_validated= true;
			
		} 
		if(empty($_POST["password"])){
			$errPassword = "Password. is required";
		}else{
			$password = test_input($_POST["password"]);
			// check if  only contains numbers
			 
				$password_validated = true;
			
		}
		
		if(empty($_POST["email"])){
			$errEmail = "Email is required";
		}else{
			$email = test_input($_POST["email"]);
			// check if e-mail address is well-formed
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			  $emailErr = "Invalid email format"; 
			}else{
				$email_validated = true;
			}
		 } 
		   
		if($expiry_validated && $password_validated &&  $email_validated){

			$sql1 = "UPDATE `candidates` SET `time_available`='$expiry',`seconds_available`='60'";
            $sql2="UPDATE `administrator` SET `email`='$email',`password`='$password'";

			if(mysqli_query($conn, $sql1) && mysqli_query($conn,$sql2))
            {



				echo '<div class="alert alert-success alert-dismissable text-center"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a><strong>Success!</strong> Setting Completely Saved.</div>';
				//header("Location: login.php");
			}else{
				echo '<div class="alert alert-danger text-center"><strong>Error! Just Occured</strong>.</div>';
			}
		}
  
	}	
   
   
?>   
 <?php
 
 require_once("header.php");



 ?>
		<div class="container">
			
			<div class="container">
				<div class="row">
					<div class="col-sm-2 .visible-xs, hidden-xs"></div>
					<div class="col-sm-8 jumbotron">
						<div class="header text-center">
						  <h4>Settings</h4>
						
                        </div>
						<div class="container">
						  <form role="form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
							<div class="form-group">
<div class="row">
<label>Expiry Time/Count Down(Min)</label>
<input type="number" class="form-control" value="60" name="expirytime" placeholder="Expiry Time Countdown (Min)">
*<?php   echo $errTime;    ?>
</div>
<div class="row">
<label>Admin Email</label>
<input type="text" class="form-control" value="<?php   echo $falseEmail;   ?>" name="email" placeholder="Email For Admin Login">
*<?php   echo $errEmail;    ?>
</div>
<div class="row">
<label>Admin Password</label>
<input type="text" class="form-control" value="<?php   echo $falsePassword;   ?>" name="password" placeholder="Password For Admin Login">
*<?php   echo $errPassword;    ?>
</div>

						 		
                            <br><br>
									<button type="submit" name="submit" class="btn btn-primary btn-block" style="border-radius:12px;"><span class="glyphicon glyphicon-off"></span> Save</button>
								</div>
							</div>
						  </form>
						</div>	
					</div>	
					<div class="col-sm-2 .visible-xs, hidden-xs"></div>
				</div>
			</div>
			   
			</div>
		</div>
		
		
		<script src="../assets/js/bootstrap.min.js"></script>
		<script src="../assets/js/jquery-3.1.1.min.js"></script>
	</body>
</html>
<?php ob_end_flush(); ?>