<?php




if($_GET["rel"]){

    session_start();
    include_once "../includes/dbconnection.php";
	if(!(isset($_SESSION["s_firstname"]))){
        die("Access denied");
    }
    
	function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
      } 

      $best=test_input($_GET["rel"]);
      
    $sql="DELETE FROM `candidates` WHERE `candidates_id`='$best'";

    if(mysqli_query($conn,$sql)){

header("location:users.php?job=success");

    }


}