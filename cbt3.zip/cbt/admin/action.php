<?php






if(isset($_POST["work"])){

$quest=$_POST["quest"];
$ask=$_POST["ask"];
$posta=$_POST["posta"];
$postb=$_POST["postb"];
$postc=$_POST["postc"];
$postd=$_POST["postd"];
$right_ans=$_POST["right_ans"];

$file_name=$_POST["filename"];
$addr="../files/".$file_name;

$source=file_get_contents($addr);




$construct= $quest.". ".$ask."|{"."'".$posta."'_'".$postb."'_'".$postc."'_'".$postd."'}|{".$right_ans."}";

$all=$source.$construct;



 if(file_put_contents($addr,$all)){
     
?>


 
<script>
window.history.back();

     </script>
 
<?php
 }

 else{

    echo"<h1>An Error Occured</h1>";
 }
}





if(isset($_POST["delete"]))
{

$file_name=$_POST["filename"];

$call="../files/".$file_name;

 file_put_contents($call,"");

echo "Completely deleted";
?>
 <script>
window.history.back();

     </script>
 
<?php



}

?>