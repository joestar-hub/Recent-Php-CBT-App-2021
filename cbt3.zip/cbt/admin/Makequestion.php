<?php
    ob_start();
    session_start();
    include_once "../includes/dbconnection.php";
	if(!(isset($_SESSION["s_firstname"]))){
        die("Access denied");
    }
	
	function test_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    } 
	
   
   
?>   
<!--Header Begins Here-->
<?php

require_once("header.php");

?>
		<div class="container">
			
			<div class="container">
				<div class="row">
					<div class="col-sm-2 .visible-xs, hidden-xs"></div>
					<div class="col-sm-8 jumbotron">
						<div class="header text-center">
						  <h4>Choose Subject  Of Exam</h4>
						
						
						</div>
						<div class="container"> 

<ul class="list-group">
	<?php
$real=mysqli_query($conn,"SELECT * FROM courses");
while($rd=mysqli_fetch_assoc($real)){ 

?>
	<a href="bakequestion.php?code=<?php  echo $rd["course_code"];  ?>"><li class="list-group-item"><?php        echo $rd["course_name"];    ?></li></a>
	 <?php

}
?>
</ul>




	
                           
                           <br><br>
								</div>
							</div>
						  </form>
						</div>	
					</div>	
					<div class="col-sm-2 .visible-xs, hidden-xs"></div>
				</div>
			</div>
			
			<!----> 
		
		
		<script src="../assets/js/bootstrap.min.js"></script>
		<script src="../assets/js/jquery-3.1.1.min.js"></script>
	</body>
</html>
<?php ob_end_flush(); ?>