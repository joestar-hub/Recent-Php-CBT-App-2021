 <?php

header("location:makequestion.php");



?>