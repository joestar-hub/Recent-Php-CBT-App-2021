<?php
    ob_start();
    session_start();
    include_once "../includes/dbconnection.php";
	if(!(isset($_SESSION["s_firstname"]))){
        die("Access denied");
    }
	
	function test_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    } 
	
   
   
?>    <?php

require_once("header.php");

?>
		<div class="container">
			
			<div class="container">
				<div class="row">
					<div class="col-sm-2 .visible-xs, hidden-xs"></div>
					<div class="col-sm-8 jumbotron">
						<div class="header text-center">
						  <h4><?php  echo $_GET["code"];   ?></h4>
						<center>

<button class="btn btn-success" data-toggle="modal" data-target="#add">Add  Question</button>

<!-- 
<button class="btn btn-primary" data-toggle="modal" data-target="#change">Change  Question</button>
 -->

<button class="btn btn-danger" data-toggle="modal" data-target="#delete">Delete</button>






                        </center>
						
						</div>
						<div class="container"> 

                            <div id="slice" class="slice">
 
	<?php

    $find=$_GET["code"];
$real=mysqli_query($conn,"SELECT * FROM courses WHERE course_code='$find'");
while($rd=mysqli_fetch_assoc($real)){ 

    $filename=$rd["filename"];

    $show=file_get_contents("../files/".$filename);

?>
	<div>
<?php if(empty($show)){echo "<h2>Empty: No Questions Set</h2>";} else{echo $show;}   ?>

</div>
	 <?php

}
?> 


</div>
	
                           
                           <br><br>
								</div>
							</div>
						  </form>
						</div>	
					</div>	
					<div class="col-sm-2 .visible-xs, hidden-xs"></div>
				</div>
			</div>
			
			<!----> 
		
            <script src="../assets/js/jquery-3.2.1.min.js"></script>

		<script src="../assets/js/bootstrap.min.js"></script>
		
<script>
var info=document.querySelector("#slide");

$(document).ready(function () 
{





    

// //start process 4
// var text1 =$("#slice").html();
//     var arrayList= text1.split("}|");
    
// // build result HTML
// var resultString = "";
//  for (var i = 0; i < arrayList.length; i++) {
//  resultString+=" " + arrayList[i] + "</br><b>Answers for above</b>";
//  }

//  // print out to page
//  var blk = document.getElementById("slice");
//  blk.innerHTML = resultString;




/** Start Process 1 */
    var text1 =$("#slice").html();
    var arrayList= text1.split("|");
    
// build result HTML
var resultString = "";
 for (var i = 0; i < arrayList.length; i++) {
 resultString+=" " + arrayList[i] + "<br />";
 }

 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = resultString;















// start process 3

 var text1 =$("#slice").html();
    var arrayList= text1.split("{");
    
// build result HTML
var resultString = "";
 for (var i = 0; i < arrayList.length; i++) {
 resultString+="" + arrayList[i] + "<b>Options[A,B,C,D,E]</b></br>";
 }















 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = resultString;

//start process 4
 var text1 =$("#slice").html();
    var arrayList= text1.split("}");
    
// build result HTML
var resultString = "";
 for (var i = 0; i < arrayList.length; i++) {
 resultString+=" " + arrayList[i] + "";
 }

 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = resultString;


//start process 5
var text1 =$("#slice").html();
    var arrayList= text1.split("_");
    
// build result HTML
var resultString = "";
 for (var i = 0; i < arrayList.length; i++) {
 resultString+="</br>" + arrayList[i] + "";
 }

 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = resultString;






//start process 6
var text1 =$("#slice").html();
    var arrayList= text1.replace(/'/g,"");
     

 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = arrayList;





//start process 7
var text1 =$("#slice").html();
    var arrayList= text1.split("'");
    
// build result HTML
var resultString = "";
 for (var i = 0; i < arrayList.length; i++) {
 resultString+="" + arrayList[i] + "";
 }

 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = resultString;
 





    
});





    </script>

<!-- Modal -->
<div class="modal fade" id="add" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Add New Question</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="post" action="action.php">
<input type="number" name="quest" class="form-control" placeholder="Question number"/>
<textarea class="form-control" name="ask">Question to Ask?</textarea>
<div class="form-row">
<input type="text" class="form-control col-3" name="posta" placeholder="Option A";/>
<input type="text" class="form-control col-3" name="postb" placeholder="Option B";/>
<input type="text" class="form-control col-3" name="postc" placeholder="Option C";/>
<input type="text" class="form-control col-3" name="postd" placeholder="Option D";/>
<select class="form-control" name="right_ans">
  <option>--Select Right Answer--</option>
<option value="A">A</option>
<option value="B">B</option>
<option value="C">C</option>
<option value="D">D</option>


</select>


<input type="hidden" value="<?php  echo $filename;  ?>" hidden class="form-control" name="filename"/>



</div>





      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="work" class="btn btn-primary">Submit</button>
        
</form>
      </div>
    </div>
  </div>
</div>




<!-- Modal -->
<div class="modal fade" id="change" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Change Question</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="action.php">

<input type="text" class="form-control" placeholder="question number" name="questno"/>



<input type="hidden" value="<?php  echo $filename;  ?>" hidden class="form-control" name="filename"/>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="subject" name="change" class="btn btn-primary">Start Changes</button>
      </div>
      

</form>
    </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="delete" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Delete Question</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="action.php"/>
      Do you want All the questions?
      


<input type="hidden" value="<?php  echo $filename;  ?>" hidden class="form-control" name="filename"/>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No, Back Off</button>
        <button type="submit" name="delete" class="btn btn-primary">Yes, Delete</button>
</form>
      </div>
    </div>
  </div>
</div>
















	</body>
</html>
<?php ob_end_flush(); ?>