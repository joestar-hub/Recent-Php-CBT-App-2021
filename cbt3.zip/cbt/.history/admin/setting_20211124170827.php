<?php
    ob_start();
    session_start();
    include_once "../includes/dbconnection.php";
	if(!(isset($_SESSION["s_firstname"]))){
        die("Access denied");
    }
	
	function test_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
	$fullname = $registration_no = $phone_no = $email = $course1_id = $course2_id = $course3_id = $course4_id = "";
	$fullnameErr = $registration_noErr = $phone_noErr = $emailErr = $coursesErr = "";
	$fullname_validated = $registration_no_validated = $phone_no_validated = $email_validated = $course1_id_validated = $course2_id_validated = $course3_id_validated = $course4_id_validated = "";
	
	if (isset($_POST["submit"])) {
		
		if(empty($_POST["fullname"])){
			$fullnameErr = "Full Name is required";
		}else{
			$fullname = test_input($_POST["fullname"]);
			// check if name only contains letters and whitespace
			if (!preg_match("/^[a-zA-Z ]*$/",$fullname)) {
			$fullnameErr = "Only letters and white space allowed"; 
			}
			else{
				$fullname_validated = true;
			}
		}
		
		if(empty($_POST["registration_no"])){
			$registration_noErr = "Reg no. is required";
		}else{
			$registration_no = test_input($_POST["registration_no"]);
			// check if reg no. only contains letters and numbers
			if (!preg_match("/^[a-zA-Z0-9]*$/",$registration_no)) {
			$registration_noErr = "Only letters and numbers allowed"; 
			}
			else{
				//check if registration_no already exist
				$sql = "SELECT * FROM candidates WHERE candidates_registration_no = '$registration_no'";
				$result = mysqli_query($conn, $sql);
				$result_check = mysqli_num_rows($result);
				if($result_check > 0){
					$registration_noErr = "Registration no. already Exist";
				}else{
					$registration_no_validated = true;
				}
			}
		}
		
		if(empty($_POST["phone_no"])){
			$phone_noErr = "Reg no. is required";
		}else{
			$phone_no = test_input($_POST["phone_no"]);
			// check if  only contains numbers
			if (!preg_match("/^[0-9]*$/",$phone_no)) {
			$phone_noErr = "Only numbers allowed"; 
			}
			else{
				$phone_no_validated = true;
			}
		}
		
		if(empty($_POST["email"])){
			$emailErr = "Email is required";
		}else{
			$email = test_input($_POST["email"]);
			// check if e-mail address is well-formed
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			  $emailErr = "Invalid email format"; 
			}else{
				$email_validated = true;
			}
		 } 
		  
		if(empty($_POST["course1_id"])){
			$coursesErr = "Invalid course 1 Selected ";
		}else{
			$course1_id = test_input($_POST["course1_id"]);
			if($course1_id == "Select"){
				$coursesErr = "Invalid course 1 Selected ";
			}else{
				$course1_id_validated = true;
			}
		}
		
		if(empty($_POST["course2_id"])){
			$coursesErr = "Invalid course 2 Selected ";
		}else{
			$course2_id = test_input($_POST["course2_id"]);
			if($course2_id == "Select course 2"){
				$coursesErr = "Invalid course 2 Selected ";
			}else{
				$course2_id_validated = true;
			}
		}
		
		if(empty($_POST["course3_id"])){
			$coursesErr = "Invalid course 3 Selected ";
		}else{
			$course3_id = test_input($_POST["course3_id"]);
			if($course3_id == "Select course 3"){
				$coursesErr = "Invalid course 3 Selected ";
			}else{
				$course3_id_validated = true;
			}
		}
		
		if(empty($_POST["course4_id"])){
			$coursesErr = "Invalid course 4 Selected ";
		}else{
			$course4_id = test_input($_POST["course4_id"]);
			if($course4_id == "Select course 4"){
				$coursesErr = "Invalid course 4 Selected ";
			}else{
				$course4_id_validated = true;
			}
		}
		
		if($fullname_validated && $registration_no_validated && $phone_no_validated && $email_validated && $course1_id_validated && $course2_id_validated && $course3_id_validated && $course4_id_validated){
			$sql = "INSERT INTO candidates (candidates_fullname, candidates_registration_no, candidates_phone_no, candidates_email, course1_id, course2_id, course3_id, course4_id) VALUES ('$fullname', '$registration_no', '$phone_no', '$email', '$course1_id', '$course2_id', '$course3_id', '$course4_id')";
			if(mysqli_query($conn, $sql)){
				echo '<div class="alert alert-success alert-dismissable text-center"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a><strong>Success!</strong> User created successfully.</div>';
				//header("Location: login.php");
			}else{
				echo '<div class="alert alert-danger text-center"><strong>Error!</strong>.</div>';
			}
		}
  
	}	
   
   
?>   

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>JAMB mock e-Testing</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="icon"  href="../assets/img/logo.png">
		<link rel="stylesheet" href="../assets/css/font-awesome.min.css" />
		<link rel="stylesheet" href="../assets/css/bootstrap.css">
		<link rel="stylesheet" href="../assets/css/bootstrap-grid.css">
		<link rel="stylesheet" href="../assets/css/bootstrap-grid.min.css">
		<link rel="stylesheet" href="../assets/css/bootstrap-reboot.css">
		<link rel="stylesheet" href="../assets/css/bootstrap-reboot.min.css">
		<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="../assets/css/main.css">
		<style>
		</style>
	</head>
	<body>
		
		<nav class="navbar navbar-expand-md bg-dark navbar-dark">
		  <a class="navbar-brand" href="#">Administrator</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
			<span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
			<ul class="navbar-nav">
			  <li class="nav-item">
				<a class="nav-link" href="users.php">Candidates</a>
			  </li>   
			  <li class="nav-item">
				<a class="nav-link" href="users.php">Create Question</a>
			  </li>    
			  <li class="nav-item">
				<a class="nav-link" href="users.php">View Question</a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="users.php">Bulk Enroll</a>
			  </li> 

			</ul>
		  </div>  
		</nav>
		
		<div class="container">
			
			<div class="container">
				<div class="row">
					<div class="col-sm-2 .visible-xs, hidden-xs"></div>
					<div class="col-sm-8 jumbotron">
						<div class="header text-center">
						  <h4>Settings</h4>
						
                        </div>
						<div class="container">
						  <form role="form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
							<div class="form-group">
<div class="row">
<label>Expiry Time/Count Down</label>
<input type="number" class="form-control" name="expirytime" placeholder="Expiry Time Countdown">
</div>
<div class="row">
<label>Email</label>
<input type="number" class="form-control" name="email" placeholder="Expiry Time Countdown">
</div>
<div class="row">
<label>Password</label>
<input type="number" class="form-control" name="expirytime" placeholder="Expiry Time Countdown">
</div>

						 		
                            <br><br>
									<button type="submit" name="submit" class="btn btn-primary btn-block" style="border-radius:12px;"><span class="glyphicon glyphicon-off"></span> Save</button>
								</div>
							</div>
						  </form>
						</div>	
					</div>	
					<div class="col-sm-2 .visible-xs, hidden-xs"></div>
				</div>
			</div>
			   
			</div>
		</div>
		
		
		<script src="../assets/js/bootstrap.min.js"></script>
		<script src="../assets/js/jquery-3.1.1.min.js"></script>
	</body>
</html>
<?php ob_end_flush(); ?>