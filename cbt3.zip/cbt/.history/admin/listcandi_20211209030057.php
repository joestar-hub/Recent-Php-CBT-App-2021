<?php
    ob_start();
    session_start();
    include_once "../includes/dbconnection.php";
	if(!(isset($_SESSION["s_firstname"]))){
        die("Access denied");
    }
	
	function test_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    } 


    if(isset($_GET["find"])){

        $limited=test_input($_GET["find"]);


    }

    

    if(!isset($_GET["find"])){

        $limited=0;


    }











   
   
?>   
<!--Header Begins Here-->
<?php

require_once("header.php");

?>
		
		<div class="container">
</br>
</br>
</br>
<center><h2>List Of Candidates </h2></center>

<center><a href="#">Download All </a></center>
</br>

			<div class="container-fluid">
                <table class="table table-striped">
                    <thead class="thead-dark">
                      <tr>
                        <th>ID</th>  
                        <th>Full name</th>
                        <th>Reg no.</th>
                        <th>Phone no.</th>
                        <th>Email</th>
						<th>Courses</th>
						
						<th>Scores</th>
						<th>Overall Score</th>
						<th>Controls</th>
						<th>Department</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $sql = "SELECT * FROM `candidates` WHERE candidates_id>=$limited LIMIT 5";
                    	    $result = mysqli_query($conn, $sql);
                    	    while($candidate = mysqli_fetch_assoc($result))
							{								
                    	        echo '<tr>';
                    	        echo '<td>'.$candidate['candidates_id'].'</td>';
                    	        echo '<td>'.$candidate['candidates_fullname'].'</td>';
                    	        echo '<td>'.$candidate['candidates_registration_no'].'</td>';
                    	        echo '<td>'.$candidate['candidates_phone_no'].'</td>';
                    	        echo '<td>'.$candidate['candidates_email'].'</td>';
								//Courses
								echo '<td>';
								$courses_sql = "SELECT * FROM `courses` WHERE `id` = ".$candidate['course1_id']." OR `id` = ".$candidate['course2_id']." OR `id` = ".$candidate['course3_id']." OR `id` = ".$candidate['course4_id'];
								$courses_result = mysqli_query($conn, $courses_sql);
								while($course = mysqli_fetch_assoc($courses_result)){
									echo '<i>'.$course['course_name'].'</i><br>';									
								}
								echo '</td>';
								 
								//Scores 
								echo '<td>';
								$course1_score = explode(',', $candidate['course1_score']);
								$course2_score = explode(',', $candidate['course2_score']);
								$course3_score = explode(',', $candidate['course3_score']);
								$course4_score = explode(',', $candidate['course4_score']);
								$correct_option1 = explode(',', $candidate['correct_option1']);
								$correct_option2 = explode(',', $candidate['correct_option2']);
								$correct_option3 = explode(',', $candidate['correct_option3']);
								$correct_option4 = explode(',', $candidate['correct_option4']);
								
								$subject_1_score = 0;
								for($i = 0; $i < count($course1_score); $i++) {
									if(strtoupper($course1_score[$i]) === strtoupper($correct_option1[$i])){
										$subject_1_score++;
									}									
								}
								
								$subject_2_score = 0;
								for($i = 0; $i < count($course2_score); $i++) {
									if(strtoupper($course2_score[$i]) === strtoupper($correct_option2[$i])){
										$subject_2_score++;
									}									
								}
								
								$subject_3_score = 0;
								for($i = 0; $i < count($course3_score); $i++) {
									if(strtoupper($course3_score[$i]) === strtoupper($correct_option3[$i])){
										$subject_3_score++;
									}									
								}
								
								$subject_4_score = 0;
								for($i = 0; $i < count($course4_score); $i++) {
									if(strtoupper($course4_score[$i]) === strtoupper($correct_option4[$i])){
										$subject_4_score++;
									}									
								}


								 $mi=round(($subject_1_score*100)/60);
								 $yi=round(($subject_2_score*100)/50);
								$ton=round(($subject_3_score*100)/50);
								 $se=round(($subject_4_score*100)/50);

								$yakai=$mi+$yi+$ton+$se;

								// update the database
								$id=$candidate['candidates_id'];

								$sql=" UPDATE `candidates` SET  `total_score`='$yakai' WHERE candidates_id='$id'";

								$action=mysqli_query($conn,$sql);

								echo '<i id="one">'.round(($subject_1_score*100)/60).'</i><br>';
								echo '<i id="two">'.round(($subject_2_score*100)/50).'</i><br>';
								echo '<i id="three">'.round(($subject_3_score*100)/50).'</i><br>';
								echo '<i id="four">'.round(($subject_4_score*100)/50).'</i><br>';	
								// echo '<i>'.round( ($subject_4_score*100)/50) + ($subject_3_score*100)/50) + ($subject_2_score*100)/50)+($subject_1_score*100)/60).'</i><br>';				
								echo '</td>';
									echo "<td><p id='jine'>".$yakai."</p> </td>";							
								echo '	<td><a href="delete.php?rel='.$candidate["candidates_id"].'" class="btn btn-danger">Delete</a></td>';
                    	        
								echo '<td>'.$candidate["department"]."</td></tr>";
                    	    }
                    	?>
						<caption> 
					<div class="from-row"> 
		<a style="float:left;" href="#"class="btn  btn-primary">Next</a>
		<a style="float:right;" href="#"class="btn  btn-primary">Prev</a>

						</caption>
						</div>
                     </tbody>
                </table>  
			</div>
		</div>
		
		<script src="../assets/js/bootstrap.min.js"></script>
		<script src="../assets/js/jquery-3.2.1.min.js"></script>

<script>

	$(document).ready(function () {
		
var one=$("#one").val();;
var two=$("#two").val();;
var three=$("#three").val();;
var four=$("#four").val();;

var jine=$("#jine").val(one+two+three+four);




	});






</script>





	</body>
</html>
<?php ob_end_flush(); ?>