<?php
    ob_start();
    session_start();
    include_once "../includes/dbconnection.php";
	if(!(isset($_SESSION["s_firstname"]))){
        die("Access denied");
    }
	
	function test_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    } 
	
   
   
?>   

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>JAMB mock e-Testing</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="icon"  href="../assets/img/logo.png">
		<link rel="stylesheet" href="../assets/css/font-awesome.min.css" />
		<link rel="stylesheet" href="../assets/css/bootstrap.css">
		<link rel="stylesheet" href="../assets/css/bootstrap-grid.css">
		<link rel="stylesheet" href="../assets/css/bootstrap-grid.min.css">
		<link rel="stylesheet" href="../assets/css/bootstrap-reboot.css">
		<link rel="stylesheet" href="../assets/css/bootstrap-reboot.min.css">
		<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="../assets/css/main.css">
		<style>
		</style>
	</head>
	<body>
		
		<nav class="navbar navbar-expand-md bg-dark navbar-dark">
		  <a class="navbar-brand" href="#">Administrator</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
			<span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
			<ul class="navbar-nav">
			  <li class="nav-item">
				<a class="nav-link" href="users.php">Candidates</a>
			  </li>   
			  <li class="nav-item">
				<a class="nav-link" href="makequestion.php">Create Question</a>
			  </li>    
			  <li class="nav-item">
				<a class="nav-link" href="readquestion.php">View Question</a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="bulkenroll.php">Bulk Enroll</a>
			  </li> 
              <li class="nav-item">
				<a class="nav-link" href="setting.php">Setting</a>
			  </li> 

			</ul>
		  </div>  
		</nav>
		
		<div class="container">
			
			<div class="container">
				<div class="row">
					<div class="col-sm-2 .visible-xs, hidden-xs"></div>
					<div class="col-sm-8 jumbotron">
						<div class="header text-center">
						  <h4><?php  echo $_GET["code"];   ?></h4>
						<center>

<button class="btn btn-success" data-toggle="modal" data-target="#add">Add  Question</button>


<button class="btn btn-primary" data-toggle="modal" data-target="#change">Change  Question</button>


<button class="btn btn-danger" data-toggle="modal" data-target="#delete">Delete</button>






                        </center>
						
						</div>
						<div class="container"> 

                            <div id="slice" class="slice">
 
	<?php

    $find=$_GET["code"];
$real=mysqli_query($conn,"SELECT * FROM courses WHERE course_code='$find'");
while($rd=mysqli_fetch_assoc($real)){ 

    $filename=$rd["filename"];

    $show=file_get_contents("../files/".$filename);

?>
	<div>
<?php echo $show   ?>

</div>
	 <?php

}
?> 


</div>
	
                           
                           <br><br>
								</div>
							</div>
						  </form>
						</div>	
					</div>	
					<div class="col-sm-2 .visible-xs, hidden-xs"></div>
				</div>
			</div>
			
			<!----> 
		
            <script src="../assets/js/jquery-3.2.1.min.js"></script>

		<script src="../assets/js/bootstrap.min.js"></script>
		
<script>
var info=document.querySelector("#slide");

$(document).ready(function () 
{





    

//start process 4
var text1 =$("#slice").html();
    var arrayList= text1.split("}|");
    
// build result HTML
var resultString = "";
 for (var i = 0; i < arrayList.length; i++) {
 resultString+=" " + arrayList[i] + "</br><b>Answers for above</b>";
 }

 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = resultString;




/** Start Process 1 */
    var text1 =$("#slice").html();
    var arrayList= text1.split("|");
    
// build result HTML
var resultString = "";
 for (var i = 0; i < arrayList.length; i++) {
 resultString+=" " + arrayList[i] + "<br />";
 }

 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = resultString;















// start process 3

 var text1 =$("#slice").html();
    var arrayList= text1.split("{");
    
// build result HTML
var resultString = "";
 for (var i = 0; i < arrayList.length; i++) {
 resultString+="" + arrayList[i] + "<b>Options[A,B,C,D,E]</b></br>";
 }















 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = resultString;

//start process 4
 var text1 =$("#slice").html();
    var arrayList= text1.split("}");
    
// build result HTML
var resultString = "";
 for (var i = 0; i < arrayList.length; i++) {
 resultString+="<b></b> " + arrayList[i] + "</br>";
 }

 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = resultString;


//start process 5
var text1 =$("#slice").html();
    var arrayList= text1.split("_");
    
// build result HTML
var resultString = "";
 for (var i = 0; i < arrayList.length; i++) {
 resultString+="</br>" + arrayList[i] + "";
 }

 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = resultString;






//start process 6
var text1 =$("#slice").html();
    var arrayList= text1.replace(/'/g,"");
     

 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = arrayList;





//start process 7
var text1 =$("#slice").html();
    var arrayList= text1.split("'");
    
// build result HTML
var resultString = "";
 for (var i = 0; i < arrayList.length; i++) {
 resultString+="" + arrayList[i] + "";
 }

 // print out to page
 var blk = document.getElementById("slice");
 blk.innerHTML = resultString;









    
});





    </script>

<!-- Modal -->
<div class="modal fade" id="add" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Add New Question</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form>
<input type="text" class="form-control" placeholder="Question number"/>
<textarea class="form-control">Question to Ask?</textarea>





</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Understood</button>
      </div>
    </div>
  </div>
</div>




<!-- Modal -->
<div class="modal fade" id="change" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Change Question</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Understood</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="delete" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Delete Question</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Understood</button>
      </div>
    </div>
  </div>
</div>
















	</body>
</html>
<?php ob_end_flush(); ?>