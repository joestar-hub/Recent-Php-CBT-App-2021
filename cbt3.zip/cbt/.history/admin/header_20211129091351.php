<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Imo State Univeristy Owerri CBT App</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="icon"  href="../assets/img/logo.png">
		<link rel="stylesheet" href="../assets/css/font-awesome.min.css" />
		<link rel="stylesheet" href="../assets/css/bootstrap.css">
		<link rel="stylesheet" href="../assets/css/bootstrap-grid.css">
		<link rel="stylesheet" href="../assets/css/bootstrap-grid.min.css">
		<link rel="stylesheet" href="../assets/css/bootstrap-reboot.css">
		<link rel="stylesheet" href="../assets/css/bootstrap-reboot.min.css">
		<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="../assets/css/main.css">
		<style>
		</style>
	</head>
	<body>
		
		<nav class="navbar navbar-expand-md bg-dark navbar-dark">
		  <a class="navbar-brand" href="#">Administrator</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
			<span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
			<ul class="navbar-nav">
			  <li class="nav-item">
				<a class="nav-link" href="users.php">Candidates</a>
			  </li>   
			  <li class="nav-item">
				<a class="nav-link" href="makequestion.php">Create Question</a>
			  </li>    
			  <li class="nav-item">
				<a class="nav-link" href="readquestion.php">View Question</a>
			  </li>
<!-- 
			  <li class="nav-item">
				<a class="nav-link" href="bulkenroll.php">Bulk Enroll</a>
			  </li>  -->

			  <li class="nav-item">
				<a class="nav-link" href="setting.php">Setting</a>
			  </li> 

			</ul>
		  </div>  
		</nav>