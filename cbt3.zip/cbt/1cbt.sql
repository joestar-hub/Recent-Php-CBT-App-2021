-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2021 at 11:20 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `1cbt`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`id`, `firstname`, `lastname`, `level`, `password`, `email`) VALUES
(1, 'on', 'peter', '0', '412', '123@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `candidates_id` int(11) NOT NULL,
  `candidates_fullname` varchar(255) NOT NULL,
  `candidates_registration_no` varchar(255) NOT NULL,
  `candidates_phone_no` varchar(255) NOT NULL,
  `candidates_email` varchar(255) NOT NULL,
  `course1_id` int(11) NOT NULL,
  `course2_id` int(11) NOT NULL,
  `course3_id` int(11) NOT NULL,
  `course4_id` int(11) NOT NULL,
  `course1_score` varchar(255) DEFAULT '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0',
  `course2_score` varchar(255) DEFAULT '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0',
  `course3_score` varchar(255) DEFAULT '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0',
  `course4_score` varchar(255) DEFAULT '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0',
  `time_available` int(11) NOT NULL DEFAULT 79,
  `correct_option1` varchar(255) DEFAULT '1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1',
  `correct_option2` varchar(255) DEFAULT '1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1',
  `correct_option3` varchar(255) DEFAULT '1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1',
  `correct_option4` varchar(255) DEFAULT '1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1',
  `seconds_available` int(11) DEFAULT NULL,
  `department` text DEFAULT NULL,
  `total_score` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`candidates_id`, `candidates_fullname`, `candidates_registration_no`, `candidates_phone_no`, `candidates_email`, `course1_id`, `course2_id`, `course3_id`, `course4_id`, `course1_score`, `course2_score`, `course3_score`, `course4_score`, `time_available`, `correct_option1`, `correct_option2`, `correct_option3`, `correct_option4`, `seconds_available`, `department`, `total_score`) VALUES
(1, 'Ugwu Chinonso', '5202829271EF', '08123456789', 'petecdev@gmail.com', 1, 2, 6, 7, 'B,B,C,C,C,C,C,C,C,C', ' 0,0,0,0,0,0,0,0,0,0', '0,0,0,0,0,0,0,0,0,0', ' 0,0,0,0,0,0,0,0,0,0', 60, 'D,D,C,A,A,A,C,C,B,C,', 'D,D,C,A,D,D,C,C,A,A', 'B,A,C,B,C,A,B,B,A,C,', 'A,D,A,A,A,A,A,A,A,A,', 1, 'Life Science', '8'),
(2, 'Kedi Anthony', '5202829271EA', '08123456789', 'kedi@gmail.com', 1, 8, 9, 10, ' 0,0,0,0,0,0,0,0,0,0', '0,0,0,0,0,0,0,0,0,0', ' 0,0,0,0,0,0,0,0,0,0', '0,0,0,0,0,0,0,0,0,0', 60, 'D,D,C,A,A,A,C,C,B,C,', 'D,D,B,C,D,C,B,B,B,B,', 'A,A,A,A,A,C,B,D,A,C,', 'A,A,A,D,A,D,C,B,B,D,', 10, 'Life Science', '0');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_name` varchar(255) DEFAULT NULL,
  `course_code` varchar(255) DEFAULT NULL,
  `filename` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_name`, `course_code`, `filename`) VALUES
(1, 'USE OF ENGLISH\r\n', 'UOE', 'useofenglish.txt'),
(2, 'BIOLOGY', 'BIO', 'biology.txt'),
(3, 'MATHEMATICS', 'MAT', 'mathematics.txt'),
(4, 'Accounting', 'ACCO', 'accounting.txt'),
(5, 'Agricultural Science', 'AGC', 'agricultural_science.txt'),
(6, 'Chemistry', 'CHEM', 'chemistry.txt'),
(7, 'Physics', 'PHYS', 'physics.txt'),
(8, 'Economics', 'ECON', 'economics.txt'),
(9, 'Geography', 'GEOG', 'geograph.txt'),
(10, 'Commerce', 'BUSS', 'commerce.txt'),
(11, 'Christian Religious Studies', 'CRK', 'christian_religious_knowlegde.txt'),
(12, 'Literature In English', 'LIT', 'literature_in_english.txt'),
(13, 'Government', 'GOVT', 'government.txt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`candidates_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator`
--
ALTER TABLE `administrator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `candidates`
--
ALTER TABLE `candidates`
  MODIFY `candidates_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
